pub mod bitpack;
pub mod binary;
pub mod registers;
pub mod memory;